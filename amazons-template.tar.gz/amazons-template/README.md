## Jeu des Amazones 

### Description du projet

Il s'agit d'implémenter le [jeu des amazones](https://en.wikipedia.org/wiki/Game_of_the_Amazons)
ainsi que  des intelligences artificielles simples pour y jouer. 

### Menbres du projet 

BOUKRIF Romayssa G1.1