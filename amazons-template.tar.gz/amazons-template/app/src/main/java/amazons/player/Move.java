package amazons.player;

import amazons.board.Position;

import java.util.Objects;

public class Move {

    public static final Move DUMMY_MOVE = new Move();


    // TODO complete the code of this class

    public Position getAmazonStartPosition() {
        return null;
        // TODO
    }

    public Position getAmazonDstPosition() {
        return null;
        // TODO
    }

    public Position getArrowDestPosition() {
        return null;
        // TODO
    }


    private Move() {}


    // TODO
    public Move(Position amazonStartPosition, Position amazonDestPosition, Position arrowDestPosition) {

    }


    // TODO method equals
    // TODO method toString
    // TODO method hashCode
}
